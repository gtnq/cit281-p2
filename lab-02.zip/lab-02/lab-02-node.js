console.log('Square of 20 is ${square(10)}');
